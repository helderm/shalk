# -*- coding: utf-8 -*-
__name__ = 'shalk'
__description__ = 'A RESTful service for the Shalkspeare app'
__author__ = 'Helder Martins'
__email__ = 'heldergaray@gmail.com'
__url__ = 'http://github.com/helderm/shalk'
__version__ = '1.0.0'
